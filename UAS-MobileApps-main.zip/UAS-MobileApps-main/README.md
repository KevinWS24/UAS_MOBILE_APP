# UAS-MobileApps

Kelompok Gas Aja Dulu
Nama Kelompok
- Michael Christian Dharmawan - 00000042678
- Kevin Fernando Wijaya Sumargo - 00000044537
- Farren Yazid Pasha Anugrah - 00000044665
- Koong Hiap - 00000055136


Nama Aplikasi: Chilli 


Link Google Playstore: https://play.google.com/store/apps/details?id=id.ac.umn.chilli


Github Link:
https://github.com/Koongh/UAS-MobileApps 



Drive Video dan file:
https://drive.google.com/drive/folders/12aOpzrE3WnrpkvcKi_KfxXd-JymxeaXR?usp=sharing

